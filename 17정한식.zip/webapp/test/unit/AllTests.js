sap.ui.define([
	"exam/exprogram_17/test/unit/controller/Main.controller"
], function () {
	"use strict";
});
