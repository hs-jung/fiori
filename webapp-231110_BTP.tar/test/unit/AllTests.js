sap.ui.define([
	"project1/test/unit/controller/Main.controller"
], function () {
	"use strict";
});
